<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= APPNAME; ?></title>

<!-- bootstrap -->
<link rel="stylesheet" href="./libraries/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="./libraries/sweetalert/sweetalert.css">

<!-- JQuery -->
<script src="./libraries/jQuery/jquery-3.6.4.js"></script>
<script src="./libraries/bootstrap/js/bootstrap.js"></script>
<script src="./libraries/sweetalert/sweetalert.min.js"></script>