<?php 
define('APPNAME', 'Soal UTS no 3');
define('PATH', 'localhost');
define('SITE_ROOT', __DIR__);
define('MYROOT', $_SERVER['DOCUMENT_ROOT']);
?>